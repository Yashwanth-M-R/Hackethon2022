package com.chesire.nekome.app.discover

/**
 * List of errors that can occur within the Discover module.
 */
enum class DiscoverError {
    Error,
}
